package com.example.medusav1

import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvAdapter: recipeListAdapter
    private lateinit var textInput: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rvAdapter = recipeListAdapter(mutableListOf())

        val rv = findViewById<View>(R.id.recipeList) as RecyclerView

        rv.adapter = rvAdapter
        rv.layoutManager = LinearLayoutManager(this)
    }

    fun btnClick(View: View) {
        textInput = (findViewById<View>(R.id.recipeInput) as EditText).text.toString()
        if (textInput.trim() == "") {
            rvAdapter.addRecipe("New Recipe")
            return
        }
        rvAdapter.addRecipe(textInput)
        (findViewById<View>(R.id.recipeInput) as EditText).text.clear()
    }
}